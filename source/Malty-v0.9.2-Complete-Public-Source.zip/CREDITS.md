# Malty — the credit chain

This record is intentionally **append-only for credited contributions**. Keep the
founding credits intact when redistributing Malty, and give subsequent authors
recognition for their actual changes. Do not claim authorship of another person's work.

| Order | Contributor | Contribution |
| :---: | --- | --- |
| 01 | **AmICanceled** | Original developer. Created the foundational Canceled Agent / Perchance project and its original workflows. |
| 02 | **Background Gremlin Group (BGGG)** | Independent Malty Android application, reconstruction, preservation, integration, builds, maintenance, and community release. |

## Continuing the chain

For **pull requests to the official Malty project**, contributors **must append** a
row with their chosen public name/handle and a truthful description of what they
contributed. Existing entries remain in place and in sequence. The maintainers
may correct inaccurate claims or consolidate repeated work by the same author,
but will not remove valid founding or third-party attribution.

For independent forks, preserve the original `NOTICE`, license, and applicable
copyright/attribution notices as required by Apache-2.0. We strongly request that
fork maintainers **append their own verified contribution** to this chain and
keep earlier entries visible. Note that the Apache-2.0 license itself requires
preservation of applicable attributions and notices **but does not require**
independent forks to add a new self-credit row. Our append rule is a condition
for contributions accepted into the **official** project, not an extra license
restriction imposed on all downstream users.

Source authors retain the copyright in their own contributions. Attribution
records do not imply trademark permissions or an endorsement.
