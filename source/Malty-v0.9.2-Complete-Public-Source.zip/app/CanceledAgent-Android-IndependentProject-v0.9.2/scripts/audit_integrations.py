#!/usr/bin/env python3
"""Verify every Perchance platform import from recovered main.pjs is mapped."""
import json,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
main=root/'source-reference'/'main.pjs'
registry=json.loads((root/'source-audit'/'PLUGIN_REPLACEMENTS.json').read_text())
imports=set(re.findall(r'\{import:([a-zA-Z0-9-]+)\}',main.read_text()))
mapped=set(registry['plugins'])
missing=sorted(imports-mapped)
extra=sorted(mapped-imports)
files=[]
for k,v in registry['plugins'].items():
    for filename in v['replacement']:
        if not (root/filename).is_file():files.append((k,filename))
print('Recovered imports:',len(imports))
print('Mapped replacements:',len(mapped))
print('Missing:',missing)
print('Unexpected:',extra)
print('Unresolved replacement files:',files)
assert not missing and not extra and not files
# Installed runtime must not import, fetch, or redirect to Perchance.
for path in [*(root/'android'/'app'/'src'/'main'/'java').rglob('*.java'),*(root/'backend'/'services').rglob('*.py')]:
    text=path.read_text().lower()
    assert 'https://perchance.org/' not in text, str(path)
print('Runtime source Perchance URL scan: PASS')
